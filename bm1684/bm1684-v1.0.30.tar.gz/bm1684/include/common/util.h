#pragma once

#include <string>

std::string JoinPath(const std::string& path, const std::string& filename);