#pragma once

#include <memory>
#include <string>
#include "common/gddeploy_spdlog/fmt/fmt.h" // 确保包含了fmt库的头文件

namespace gddeploy{
    class LoggerImpl;

    class Logger {
    public:
        Logger();
        ~Logger();

        template <typename... Args>
        void log(int level, const char* file, int line, const char* format, Args&&... args) {
            std::string formatted_message = gddeploy_fmt::format(format, std::forward<Args>(args)...);
            std::string message = gddeploy_fmt::format("[{}:{}] {}", file, line, formatted_message);
            private_log(level, message);
        }
        static std::shared_ptr<Logger> GetLogger();

    private:
        std::unique_ptr<LoggerImpl> pImpl;

        // 私有方法，用于格式化并记录日志
        void private_log(int level,const std::string& message);
    };
}

#define GDDEPLOY_LEVEL_TRACE 0
#define GDDEPLOY_LEVEL_DEBUG 1
#define GDDEPLOY_LEVEL_INFO 2
#define GDDEPLOY_LEVEL_WARN 3
#define GDDEPLOY_LEVEL_ERROR 4
#define GDDEPLOY_LEVEL_CRITICAL 5
#define GDDEPLOY_LEVEL_OFF 6

#define GDDEPLOY_LOG(level, ...) gddeploy::Logger::GetLogger()->log(level, __FILE__, __LINE__, __VA_ARGS__)
#if !defined(GDDEPLOY_ACTIVE_LEVEL)
#define GDDEPLOY_ACTIVE_LEVEL GDDEPLOY_LEVEL_DEBUG
#endif

#if GDDEPLOY_ACTIVE_LEVEL <= GDDEPLOY_LEVEL_TRACE
#define GDDEPLOY_TRACE(...) GDDEPLOY_LOG(GDDEPLOY_LEVEL_TRACE, __VA_ARGS__)
#else
#define GDDEPLOY_TRACE(...) (void)0;
#endif

#if GDDEPLOY_ACTIVE_LEVEL <= GDDEPLOY_LEVEL_DEBUG
#define GDDEPLOY_DEBUG(...) GDDEPLOY_LOG(GDDEPLOY_LEVEL_DEBUG, __VA_ARGS__)
#else
#define GDDEPLOY_DEBUG(...) (void)0;
#endif

#if GDDEPLOY_ACTIVE_LEVEL <= GDDEPLOY_LEVEL_INFO
#define GDDEPLOY_INFO(...) GDDEPLOY_LOG(GDDEPLOY_LEVEL_INFO, __VA_ARGS__)
#else
#define GDDEPLOY_INFO(...) (void)0;
#endif

#if GDDEPLOY_ACTIVE_LEVEL <= GDDEPLOY_LEVEL_WARN
#define GDDEPLOY_WARN(...) GDDEPLOY_LOG(GDDEPLOY_LEVEL_WARN, __VA_ARGS__)
#else
#define GDDEPLOY_WARN(...) (void)0;
#endif

#if GDDEPLOY_ACTIVE_LEVEL <= GDDEPLOY_LEVEL_ERROR
#define GDDEPLOY_ERROR(...) GDDEPLOY_LOG(GDDEPLOY_LEVEL_ERROR, __VA_ARGS__)
#else
#define GDDEPLOY_ERROR(...) (void)0;
#endif

#if GDDEPLOY_ACTIVE_LEVEL <= GDDEPLOY_LEVEL_CRITICAL
#define GDDEPLOY_CRITICAL(...) GDDEPLOY_LOG(GDDEPLOY_LEVEL_CRITICAL, __VA_ARGS__)
#else
#define GDDEPLOY_CRITICAL(...) (void)0;
#endif

#define CHECK(a)                                                                                         \
    if (!(a))                                                                                            \
    {                                                                                                    \
        GDDEPLOY_ERROR("[{}] [{}] [{}]CHECK failed {} is nullptr", __FILE__, __FUNCTION__, __LINE__, a); \
    }

#define CHECK_NOTNULL(a)                                                                                 \
    if (NULL == (a))                                                                                     \
    {                                                                                                    \
        GDDEPLOY_ERROR("[{}] [{}] [{}]CHECK failed {} is nullptr", __FILE__, __FUNCTION__, __LINE__, a); \
    }

#define CHECK_NULL(a)                                                                                        \
    if (NULL != (a))                                                                                         \
    {                                                                                                        \
        GDDEPLOY_ERROR("[{}] [{}] [{}]CHECK failed {} is not nullptr", __FILE__, __FUNCTION__, __LINE__, a); \
    }

#define CHECK_EQ(a, b, comment, ...)          \
    if (!((a) == (b)))                        \
    {                                         \
        GDDEPLOY_ERROR(comment, __VA_ARGS__); \
    }

#define CHECK_NE(a, b, comment, ...)          \
    if (!((a) != (b)))                        \
    {                                         \
        GDDEPLOY_ERROR(comment, __VA_ARGS__); \
    }

#define CHECK_LT(a, b, comment, ...)          \
    if (!((a) < (b)))                         \
    {                                         \
        GDDEPLOY_ERROR(comment, __VA_ARGS__); \
    }

#define CHECK_GT(a, b, comment, ...)          \
    if (!((a) > (b)))                         \
    {                                         \
        GDDEPLOY_ERROR(comment, __VA_ARGS__); \
    }

// #define CHECK_LE(a, b, comment, ...)                        \
//    if(!((a) <= (b))) {                                      \
//         GDDEPLOY_ERROR(comment, __VA_ARGS__);                        \
//     }

#define CHECK_GE(a, b, comment, ...)          \
    if (!((a) >= (b)))                        \
    {                                         \
        GDDEPLOY_ERROR(comment, __VA_ARGS__); \
    }
