#ifndef GDDEPLOY_COMMON_H
#define GDDEPLOY_COMMON_H
#include <opencv2/core.hpp>
#include "core/mem/buf_surface.h"

namespace gddeploy
{
    int Align(int value, int align_bits);
    int AlignUp(int value, int align_bits);
    int AlignDown(int value, int align_bits);
    int AlignNearest(int value, int align_bits);
    void TIC(const std::string& label = "");
    void TOC(const std::string& label = "");
    void Bgr2Nv12(cv::Mat &bgr, cv::Mat &nv12);
    std::wstring GetCharacterFromVocab(const std::string &vocab);
    std::string WStringToString(const std::wstring &wide_str);
#if CALCULATE_MD5
    std::string CalculateMD5(const std::vector<uint8_t>& data);
    std::string CalculateBufSurfaceMD5(BufSurfaceParams* bufSurfaceParams);
#endif
    std::string GetFileNameWithoutSuffix(const std::string &img_path);
} // namespace gddeploy

#endif // COMMON_H