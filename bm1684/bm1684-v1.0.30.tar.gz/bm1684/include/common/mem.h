#ifndef GDDEPLOY_MEM_H
#define GDDEPLOY_MEM_H

namespace gddeploy
{

/*
memset
memcpy

memcpy(dst, src, size, direction)

drection包括：
H2D/D2H/D2D/H2D/Map
各个硬件设备的device类需要注册此接口

*/

    
} // namespace gddeploy

#endif