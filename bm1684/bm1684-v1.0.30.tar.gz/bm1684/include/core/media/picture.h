#pragma once

#include <string>
#include <vector>
#include <memory>
#include "core/mem/buf_surface.h"
#include "core/mem/buf_surface_util.h"
#include "core/mem/buf_surface_impl.h"

namespace gddeploy
{

// Picture算子抽象，一般包含resize、crop、normalize、csc等操作
// 输入输出以BufSurface为单位
class Picture
{
public:
    static Picture *Instance() noexcept
    {
        if (!pInstance_)
        {
            pInstance_ = std::unique_ptr<Picture>(new Picture());
        }
        return pInstance_.get();
    }

    int register_pic(std::string manufacturer, std::string chip, std::shared_ptr<Picture> predictor_creator) noexcept
    {
        std::unordered_map<std::string, std::shared_ptr<gddeploy::Picture>> chip_predictor_creator;
        chip_predictor_creator[chip] = predictor_creator;
        pic_map_[manufacturer] = chip_predictor_creator;

        return 0;
    }

    std::shared_ptr<gddeploy::Picture> GetPicture(std::string manufacturer, std::string chip)
    {
        if (pic_map_.count(manufacturer) == 0)
            return nullptr;
        
        if (pic_map_[manufacturer].count("any") != 0)
            return pic_map_[manufacturer]["any"];
        return pic_map_[manufacturer][chip];
    }

    int Decode(std::string pic_file, gddeploy::BufSurfWrapperPtr &dst);
    int Encode(std::string pic_file, gddeploy::BufSurfWrapperPtr &dst, const int quality = 100);

    virtual int Decode(std::vector<uint8_t> &data, gddeploy::BufSurfWrapperPtr &dst){ return 0; }
    virtual int Encode(std::vector<uint8_t> &data, gddeploy::BufSurfWrapperPtr &dst, const int quality = 100){ return 0; }

private:
    std::unordered_map<std::string, std::unordered_map<std::string, std::shared_ptr<Picture>>> pic_map_;

    static std::unique_ptr<Picture> pInstance_;
};

int register_pic_module();

}  // namespace gddeploy