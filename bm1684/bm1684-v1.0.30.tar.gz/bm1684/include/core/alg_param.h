#pragma once

#include <any>
#include <string>
#include <vector>

namespace gddeploy
{
    typedef struct
    {
        float score_threshold;
        float nms_threshold;
    } AlgDetectParam;
}