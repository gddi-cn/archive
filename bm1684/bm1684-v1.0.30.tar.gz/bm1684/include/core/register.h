#ifndef GDDEPLOY_REGISTER_H
#define GDDEPLOY_REGISTER_H

namespace gddeploy
{

int register_all_module();

}

#endif