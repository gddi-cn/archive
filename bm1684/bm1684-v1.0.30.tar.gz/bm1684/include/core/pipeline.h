#pragma once

#include <string>
#include <vector>
#include <memory>

#include "core/alg.h"

namespace gddeploy
{
/*
 *
 */

class Pipeline{
public:

    static std::shared_ptr<Pipeline>& Instance() noexcept{
        if (pInstance_ == nullptr){
            pInstance_ = std::make_shared<Pipeline>();
        }
        return pInstance_;
    }

    // 根据算法和config创建pipeline
    int CreatePipeline(std::string config, ModelPtr model, std::vector<ProcessorPtr> &processors);

    // 给pipeline添加新的processor
    int AddProcessor(std::vector<ProcessorPtr> &base, std::vector<ProcessorPtr> &new_processors);

    std::string GetPreProcConfig(ModelPtr model);

private:
    static std::shared_ptr<Pipeline> pInstance_;
};


}