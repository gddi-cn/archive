#pragma once

#include <string>
#include <memory>
#include <vector>
#include "opencv2/opencv.hpp"
#include "core/result_def.h"

namespace gddeploy {

class RtmPoseRunnerPriv;
class RtmPoseRunner{
public:
    RtmPoseRunner();

    int Init(const std::string config, std::string model_path, std::string license = "");
    int InferSync(std::string pic_path,std::string info_path, std::string save_path, bool is_draw);

private:
    std::shared_ptr<RtmPoseRunnerPriv> priv_;
};

} // namespace gddeploy

