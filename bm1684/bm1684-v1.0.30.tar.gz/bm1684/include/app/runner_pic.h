#pragma once

#include <string>
#include <memory>
#include <vector>
#include "opencv2/opencv.hpp"
#include "core/result_def.h"
#include "core/mem/buf_surface_util.h"
#include "core/media/picture.h"
#include <any>
#include <api/infer_api.h>

namespace gddeploy {

class PicRunnerPriv;
class PicRunner{
public:
    PicRunner();

    int Init(const std::string config, std::string model_path, std::string license = "");
    int Init(const std::string config, std::vector<std::string> model_paths, std::vector<std::string> license);
    int InferAsync(std::string pic_path, std::string save_path, bool is_draw);
    int InferSync(std::string pic_path, std::string save_path, bool is_draw, std::vector<std::pair<std::string, gddeploy::InferResult>>* output_results = nullptr);
    int InferSync(cv::Mat int_mat,gddeploy::InferResult &result);
    int InferMultiPicSync(std::vector<std::string> pic_path, std::string save_path, bool is_draw);
    int InferSync(gddeploy::PackagePtr in, gddeploy::PackagePtr out);
    int InferAsync(gddeploy::BufSurfWrapperPtr surf, unsigned int id, std::any callback_func);
    int InferAsync(std::string pic_path, InferAsyncCallback cb);
    int InferAsync(cv::Mat int_mat, InferAsyncCallback cb);
    
    std::shared_ptr<gddeploy::Picture> GetPicture();
private:
    std::shared_ptr<PicRunnerPriv> priv_;
};

} // namespace gddeploy

