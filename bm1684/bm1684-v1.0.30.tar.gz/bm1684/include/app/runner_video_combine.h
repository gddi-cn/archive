#pragma once

#include <string>
#include <memory>
#include <vector>

namespace gddeploy {

class VideoCombineRunnerPriv;
class VideoCombineRunner{
public:
    VideoCombineRunner();
    int Init(const std::string config, std::vector<std::string> model_paths, std::vector<std::string> license_paths);
    int OpenStreams(std::vector<std::string> video_path, std::string save_path="", bool is_draw=false, bool is_display=false);  
    int Join();

private:
    std::shared_ptr<VideoCombineRunnerPriv> priv_;
};

} // namespace gddeploy

